import React from 'react';
import BurnToEarnDashboard from '../components/BurnToEarnDashboard';

const BurnToEarnPage = () => {
  return (
    <div>
      <h1>Burn To Earn Feature</h1>
      <BurnToEarnDashboard />
    </div>
  );
};

export default BurnToEarnPage;
