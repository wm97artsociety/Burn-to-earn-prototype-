import React, { useState, useEffect, useContext } from 'react';
import { WalletContext } from '../contexts/WalletContext';
import { burnNFT, fetchRewards } from '../api/burnToEarnApi';

const BurnToEarnDashboard = () => {
  const { walletAddress } = useContext(WalletContext);
  const [tokenId, setTokenId] = useState('');
  const [rewards, setRewards] = useState('0');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (walletAddress) {
      fetchRewards(walletAddress).then(r => setRewards(r));
    }
  }, [walletAddress]);

  const handleBurn = async () => {
    setMessage('Burning NFT...');
    try {
      const res = await burnNFT(tokenId, walletAddress);
      if(res.success){
        setMessage('NFT burned successfully! Tx Hash: ' + res.txHash);
        const updatedRewards = await fetchRewards(walletAddress);
        setRewards(updatedRewards);
      } else {
        setMessage('Failed to burn NFT');
      }
    } catch (err) {
      setMessage('Error: ' + err.message);
    }
  };

  return (
    <div>
      <h2>Burn-To-Earn Dashboard</h2>
      <p>Your Wallet: {walletAddress || 'Not connected'}</p>
      <p>Your Rewards: {rewards} tokens</p>
      <input 
        type="text" 
        placeholder="Enter Token ID to burn" 
        value={tokenId} 
        onChange={(e) => setTokenId(e.target.value)} 
      />
      <button onClick={handleBurn} disabled={!walletAddress || !tokenId}>Burn NFT</button>
      <p>{message}</p>
    </div>
  );
};

export default BurnToEarnDashboard;
