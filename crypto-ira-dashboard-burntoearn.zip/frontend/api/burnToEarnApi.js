import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:5000/api/burnToEarn';

export const burnNFT = async (tokenId, userAddress) => {
  const response = await axios.post(`${API_BASE}/burn`, { tokenId, userAddress });
  return response.data;
};

export const fetchRewards = async (userAddress) => {
  const response = await axios.get(`${API_BASE}/rewards`, { params: { userAddress } });
  return response.data.rewards;
};
