import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import BurnToEarnPage from './pages/BurnToEarnPage';
import { WalletProvider } from './contexts/WalletContext';

function App() {
  return (
    <WalletProvider>
      <Router>
        <Routes>
          <Route path="/burn-to-earn" element={<BurnToEarnPage />} />
          {/* Add your other routes here */}
        </Routes>
      </Router>
    </WalletProvider>
  );
}

export default App;
