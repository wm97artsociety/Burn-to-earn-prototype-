
# Burn To Earn NFT Feature Integration

This folder contains the new feature files to integrate an NFT burn-to-earn system on Polygon.

## Setup Instructions

1. **Deploy Smart Contract**  
   - Set `NFT_CONTRACT_ADDRESS` in your environment.  
   - Run deployment script:  
     ```
     npx hardhat run scripts/deployBurnToEarn.js --network polygon
     ```  
   - Copy deployed contract address to `.env` as `BURNTOEARN_CONTRACT_ADDRESS`.

2. **Backend**  
   - Add the new routes in your Express app (e.g. `app.use('/api/burnToEarn', burnToEarnRoutes);`)  
   - Set environment variables:  
     ```
     POLYGON_RPC_URL=your_polygon_rpc_url
     PRIVATE_KEY=your_private_key
     BURNTOEARN_CONTRACT_ADDRESS=deployed_contract_address
     ```

3. **Frontend**  
   - Add the `BurnToEarnDashboard` component and route.  
   - Implement wallet interactions for burn and claim functions using ethers.js and user wallets (MetaMask).

4. **Testing**  
   - Test fully on Polygon Mumbai testnet before mainnet.  
   - Use wallets with test MATIC for gas fees.

## Notes

- Burn and claim transactions must be signed by users via wallet frontend (cannot be done server-side).  
- Backend mostly used to read highest sale and serve metadata.

## Contact

For help, reach out anytime.
