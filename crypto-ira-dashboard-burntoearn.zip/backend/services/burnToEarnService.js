const { ethers } = require('ethers');
require('dotenv').config();

const BURNTOEARN_CONTRACT_ADDRESS = process.env.BURNTOEARN_CONTRACT_ADDRESS;
const BURNTOEARN_ABI = [
  // Minimal ABI for burn and rewards functions
  "function burn(uint256 tokenId) public",
  "function getRewards(address user) public view returns (uint256)"
];

const provider = new ethers.providers.JsonRpcProvider(process.env.POLYGON_RPC_URL);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const contract = new ethers.Contract(BURNTOEARN_CONTRACT_ADDRESS, BURNTOEARN_ABI, wallet);

exports.burnNFT = async (tokenId, userAddress) => {
  const tx = await contract.burn(tokenId, { from: userAddress });
  await tx.wait();
  return tx;
};

exports.getRewards = async (userAddress) => {
  const rewards = await contract.getRewards(userAddress);
  return rewards.toString();
};
