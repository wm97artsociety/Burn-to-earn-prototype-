const express = require('express');
const router = express.Router();
const burnToEarnController = require('../controllers/burnToEarnController');

router.post('/burn', burnToEarnController.burnNFT);
router.get('/rewards', burnToEarnController.getRewards);

module.exports = router;
