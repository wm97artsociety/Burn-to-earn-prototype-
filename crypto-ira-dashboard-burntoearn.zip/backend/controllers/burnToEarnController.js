const burnToEarnService = require('../services/burnToEarnService');

exports.burnNFT = async (req, res) => {
  try {
    const { tokenId, userAddress } = req.body;
    const tx = await burnToEarnService.burnNFT(tokenId, userAddress);
    res.json({ success: true, txHash: tx.hash });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getRewards = async (req, res) => {
  try {
    const { userAddress } = req.query;
    const rewards = await burnToEarnService.getRewards(userAddress);
    res.json({ success: true, rewards });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
