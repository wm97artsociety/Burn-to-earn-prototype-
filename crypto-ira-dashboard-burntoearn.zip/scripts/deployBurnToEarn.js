
const hre = require("hardhat");

async function main() {
  const nftAddress = process.env.NFT_CONTRACT_ADDRESS;
  if (!nftAddress) {
    throw new Error("NFT_CONTRACT_ADDRESS env var not set");
  }

  const BurnToEarn = await hre.ethers.getContractFactory("BurnToEarn");
  const burnToEarn = await BurnToEarn.deploy(nftAddress);

  await burnToEarn.deployed();

  console.log("BurnToEarn deployed to:", burnToEarn.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
