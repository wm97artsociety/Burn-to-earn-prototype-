# Crypto IRA Dashboard with Burn-to-Earn NFT Feature

## Overview
This project is a crypto IRA dashboard integrated with a Polygon-based NFT Burn-to-Earn feature.

---

## Folder Structure

- **backend/**: Express backend with API endpoints
- **frontend/**: React frontend with wallet integration
- **smart-contracts/**: Solidity contracts including BurnToEarn.sol

---

## Setup Steps

### 1. Install Dependencies

```bash
npm install
cd frontend
npm install
```

### 2. Configure Environment Variables

Copy `.env.example` to `.env` and fill in your Polygon RPC URL, private key, and deployed BurnToEarn contract address.

### 3. Deploy Smart Contracts

Use your favorite Solidity deployment method (Hardhat, Truffle, etc.) to deploy `BurnToEarn.sol`.

### 4. Run Backend and Frontend

- Backend: `node backend/server.js`
- Frontend: `npm start` inside the `frontend` folder

---

## Usage

- Visit `http://localhost:3000/burn-to-earn` to access the Burn-to-Earn feature.
- Connect your wallet and burn NFTs to earn rewards.

---
